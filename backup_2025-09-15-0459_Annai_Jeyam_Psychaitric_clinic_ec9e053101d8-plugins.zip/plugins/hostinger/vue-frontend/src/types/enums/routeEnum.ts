export enum RouteBase {
	HOSTINGER_TOOLS = "hostinger-tools",
}
